<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('admin');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Week4 Performance Assessment - Derek Avery</title>
</head>
<body>
<h1>Week4 Performance Assessment - Derek Avery</h1>
<h2>Administrator Options</h2>
<h2><a href="user_accounts.php">View Users</a></h2>
<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
</body>
</html>