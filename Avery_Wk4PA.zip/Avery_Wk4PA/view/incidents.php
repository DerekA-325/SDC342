<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('tech');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Week4 Performance Assessment - Derek Avery</title>
</head>
<body>
<h1>Week4 Performance Assessment - Derek Avery</h1>
<h2>Incident Reports:</h2>
<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
<h2><a href="tech.php">Technician Home</a></h2>
</body>
</html>`