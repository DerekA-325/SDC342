<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');
require_once(__DIR__ . '\..\controller/user.php');
require_once(__DIR__ . '\..\controller/user_controller.php');

Security::checkAuthority('admin');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Week4 Performance Assessment - Derek Avery</title>
</head>
<body>
<h1>Week4 Performance Assessment - Derek Avery</h1>
<h2>User Accounts</h2>
<table>
    <tr>
        <th>User ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>E-Mail</th>
        <th>Password</th>
        <th>Registration Date</th>
        <th>User Level</th>
    </tr>
    <?php foreach(UserController::getAllPeople() as $user) : ?>
    <tr>
    <td><?php echo $user->getUserId(); ?></td>
    <td><?php echo $user->getFirstName(); ?></td>
    <td><?php echo $user->getLastName(); ?></td>
    <td><?php echo $user->getEMail(); ?></td>
    <td><?php echo $user->getPassword(); ?></td>
    <td><?php echo $user->getRegistrationDate(); ?></td>
    <td><?php echo $user->getUserLevel(); ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<h2><a href="admin.php">Admin Home</a></h2>
<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
</body>
</html>