<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('tech');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Week4 Performance Assessment - Derek Avery</title>
</head>
<body>
<h1>Week4 Performance Assessment - Derek Avery</h1>
<h2>Technician Menu</h2>
<h2><a href="incidents.php">View Incident Reports</a></h2>
<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
</body>
</html>