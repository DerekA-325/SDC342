<?php
require_once(__DIR__ . '\..\model\user_db.php');
require_once(__DIR__ . '\user.php');


class UserController {
    public static function getPeople() {
        $db = new Database();
        $dbConn = $db->getDBConn();

        if($dbConn) {
            $query = 'SELECT * FROM users;';
            return $dbConn->query($query);
        } else {
            return false;
        }
    }

    private static function rowToUser($row) {
        $user = new User($row['FirstName'],
                        $row['LastName'],
                        $row['EMail'],
                        $row['Password'],
                        $row['RegistrationDate'],
                        $row['UserLevel'],
                        $row['UserId']);
        return $user;
    }

    public static function getAllPeople() {
        $queryRes = self::getPeople();

        if($queryRes) {
            $people = array();

            foreach ($queryRes as $row) {
                $people[] = self::rowToUser($row);
            }
            return $people;
        } else {
            return false;
        }
    }

    public static function validUser($email, $password) {
        $queryRes = UsersDB::getUserByEmail($email);
        if ($queryRes) {
            $user = self::rowToUser($queryRes);
            if ($user->getPassword() === $password) {
            return $user->getUserLevel();
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}