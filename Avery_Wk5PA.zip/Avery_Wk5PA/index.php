<html>
<head>
<title>Week5 Performance Assessment - Derek Avery</title>
</head>
<body>
<h1>Week5 Performance Assessment - Derek Avery</h1>
<h2>Main Menu</h2>
<h2><a href="text_files.php">Text Files</a></h2>
<h2><a href="view_images.php">Images</a></h2>
</body>
</html>