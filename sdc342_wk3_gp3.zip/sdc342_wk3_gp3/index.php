<main>
    <h1>Menu</h1>
    <ul>
        <li><h2><a href="view/display_people.php">Manage People</a></h2></li>
        <li><h2><a href="view/display_roles.php">Manage Roles</a></h2></li>
        <li><h2><a href="view/dbconn_status.php">Database Connection Status</a></h2></li>
    </ul>
</main>