<?php
Class ImageUtilities {
    public static function GetBaseImagesList($dir) {
        $images = array();

        foreach(scandir($dir) as $file) {
            $ext = pathinfo($file, PATHINFO_EXTENSION);

            if (is_file($dir . $file) && (strtolower($ext) == 'png' || strtolower($ext) == 'jpg' || strtolower($ext) == 'jpeg')) {
                $images[] = $file;
            }
        }
        return $images;
    }

    private static function CreateDirectories($dir) {
        if (!file_exists($dir . '/200')) {
            mkdir($dir . '/200');
        }
    }

    private static function ResizeImage($orig, $type, $max) {
        $origImage = '';

        if ($type === IMAGETYPE_PNG) {
            $origImage = imagecreatefrompng($orig);
        } else if ($type === IMAGETYPE_JPEG) {
            $origImage = imagecreatefromjpeg($orig);
        }

        $origWidth = imagesx($origImage);
        $origHeight = imagesy($origImage);

        $ratioWidth = $origWidth / $max;
        $ratioHeight = $origHeight / $max;
        $ratio = max($ratioWidth, $ratioHeight);

        $newWidth = round($origWidth / $ratio);
        $newHeight = round($origHeight / $ratio);

        $newImg = imagecreatetruecolor($newWidth, $newHeight);

        imagecopyresampled($newImg, $origImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        imagedestroy($origImage);
        return $newImg;
    }

    public static function ProcessImage($file) {
        $fInfo = pathinfo($file);
        $file200 = $fInfo['dirname'] . '/200/' . $fInfo['basename'];
        self::CreateDirectories($fInfo['dirname']);

        $imgType = getimagesize($file)[2];
        $newImg200 = self::ResizeImage($file, $imgType, 200);

        switch($imgType) {
            case IMAGETYPE_PNG:
                imagepng($newImg200, $file200);
            break;
            case IMAGETYPE_JPEG:
                imagejpeg($newImg200, $file200);
            break;
            default:
            exit;
        }

        imagedestroy($newImg200);
    }

    public static function DeleteImageFiles($dir, $base) {
        unlink($dir . $base);
        unlink($dir . '/200/' . $base);
    }
}