<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('tech');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Final Practical - Derek Avery</title>
</head>
<body>
<h1>Final Practical - Derek Avery</h1>
<h2>Technician Menu</h2>
<ul>
<li><h2><a href="text_files.php">Manage Incidents</a></h2></li>
<li><h2><a href="dbconn_status.php">View Database Status</a></h2></li>
</ul>

<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
</body>
</html>