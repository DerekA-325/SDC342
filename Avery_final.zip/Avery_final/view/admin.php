<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('admin');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Final Practical - Derek Avery</title>
</head>
<body>
<h1>Final Practical - Derek Avery</h1>
<h2><a href="..\manage_users.php">Manage Users</a></h2>
<h2><a href="..\view_images.php">Manage Images</a></h2>
<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
</body>
</html>