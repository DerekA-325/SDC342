<?php
session_start();
require_once(__DIR__ . '\..\model\database.php');
require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('tech');

if (isset($_POST['logout'])) {
    Security::logout();
}

error_reporting(E_ERROR);
$db = new Database();
?>
<html>
    <head>
        <title>Final Practical - Derek Avery</title>
    </head>
    <body>
        <h1>Final Practical - Derek Avery</h1>
        <h2>Database Connection Status</h2>
        <?php if (strlen($db->getDBError())) : ?>
        <h2><?php echo $db->getDBError(); ?></h2>
        <ul>
            <li><?php echo "Database Name: " . $db->getDBName(); ?></li>
            <li><?php echo "Database User: " . $db->getDBUser(); ?></li>
            <li><?php echo "Database Name Password: " . $db->getDBUserPw(); ?></li>
        </ul>
        <?php else : ?>
        <h3><?php echo "Successfully connected"?></h3>
        <ul>
            <li><?php echo "Database Name: " . $db->getDBName(); ?></li>
            <li><?php echo "Database User: " . $db->getDBUser(); ?></li>
            <li><?php echo "Database Name Password: " . $db->getDBUserPw(); ?></li>
        </ul>
        <?php endif; ?>
        <h2><a href="tech.php">Tech Menu</a></h2>
        <form method='POST'>
        <input type="submit" value="Logout" name="logout">
        </form>
    </body>
</html>