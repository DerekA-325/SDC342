<?php
require_once(__DIR__ . '\image_utilities.php');

$dir = __DIR__ . '\\images\\';
$imgName = '';

if (isset($_POST['view'])) {
    $imgName = $_POST['image_file'];
}

if (isset($_POST['delete'])) {
    $fName = $_POST['image_file'];
    $editFile = ImageUtilities::DeleteImageFiles($dir, $fName);
    $imgName = '';
}

if (isset($_POST['upload'])) {
    $target = $dir . $_FILES['new_file']['name'];
    move_uploaded_file($_FILES['new_file']['tmp_name'], $target);
    ImageUtilities::ProcessImage($target);
    $imgName = '';
}
?>
<html>
<head>
    <title>Week5 Performance Assessment - Derek Avery</title>
</head>
<body>
    <h1>Week5 Performance Assessment - Derek Avery</h1>
    <h2>Image File Operations</h2>
    <h2><a href="index.php">Home</a></h2>
    <form method="POST">
    <h3>Image Files: <select name="image_file">
    <?php foreach(ImageUtilities::GetBaseImagesList($dir) as $file) :?>
    <option value="<?php echo $file; ?>"><?php echo $file; ?>
    </option>
    <?php endforeach; ?></select>
    <input type="submit" value="View Images" name="view">
    <input type="submit" value="Delete Image" name="delete">
    </h3>
    </form>
    <h3>Upload Image File:
    <form method="POST" enctype="multipart/form-data">
    <input type="file" name="new_file" id="new_file">
    <input type="submit" value="Upload" name="upload">
    </form>
    </h3>
    <h4>Original Image:</h4>
    <img src="images/<?php echo $imgName; ?>" alt="<?php echo $imgName; ?>">
    <h4>200px Max Image:</h4>
    <img src="images/200/<?php echo $imgName; ?>" alt="<?php echo $imgName; ?>">
</body>
</html>