<?php
require_once(__DIR__ . '\..\model\user_db.php');
require_once(__DIR__ . '\user.php');

class UserController {
    private static function rowToUser($row) {
        $user = new User($row['UserId'],
                        $row['Password'],
                        $row['FirstName'],
                        $row['LastName'],
                        $row['HireDate'],
                        $row['EMail'],
                        $row['Extension'],
                        $row['UserLevelNo']);
        return $user;
    }

    public static function validUser($email, $password) {
        $queryRes = UsersDB::getUserByEmail($email);
        if ($queryRes && $password === $queryRes['Password']) {
            //$user = self::rowToUser($queryRes);
            //if ($user->getPassword() === $password) {
            //return $user->getUserLevel();
            return $queryRes['UserLevelNo'];
            //} else {
            //    return false;
            //}
        } else {
            return false;
        }
    }
}