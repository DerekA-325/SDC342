<?php
session_start();

require_once(__DIR__ . '\..\util\security.php');

Security::checkAuthority('user');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<title>Week4 GP3 - Derek Avery</title>
</head>
<body>
<h1>Week4 GP3 - Derek Avery</h1>
<h2>Congratulations!</h2>
<h2>You're logged in as a User!</h2>
<form method='POST'>
<input type="submit" value="Logout" name="logout">
</form>
</body>
</html>