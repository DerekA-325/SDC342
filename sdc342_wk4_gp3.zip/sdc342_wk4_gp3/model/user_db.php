<?php
require_once(__DIR__ . '\database.php');

class UsersDB {
    public static function getUserByEMail($email) {
        $db = new Database();
        $dbConn = $db->getDBConn();

        if($dbConn) {
            $query = "SELECT * FROM users
                    WHERE users.EMail = '$email'";

            $result = $dbConn->query($query);
            return $result->fetch_assoc();
        } else {
            return false;
        }
    }
}